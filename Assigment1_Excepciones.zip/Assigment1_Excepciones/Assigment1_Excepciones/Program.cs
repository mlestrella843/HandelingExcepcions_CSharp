﻿using System;
using System.Data;
using System.Diagnostics;
using System.Numerics;
using System.Threading;
using System.Formats;
using System.Text.RegularExpressions;
using System.Collections.Generic;



namespace Assig_1_ExceptionHandler
{

    //---------------Class derived from the Exception class.-------------------
    //This class is used to validate the form in which the name of the arithmetic operation is entered.
    //but also I used specific exceptions directly in the catch.
    class Invalid_Calculator : Exception
    {
        public Invalid_Calculator() { }  //Constructor

        public Invalid_Calculator(string name)  //Method that receive the name to validate.
           : base(String.Format("Invalid Name: {0}", name))
        {
        }
    }

    // ----------------Class Calculator-----------------------------
    class Calculator
    {
        public int Numero1 { get; set; }
        public int Numero2 { get; set; }
        public string Operation { get; set; }

        public Calculator() //Constructor 
        {
        }

        //----Methods-----------------------------------------------
        public int Divide_Calculator(int numero1, int numero2)
        {
            return numero1 / numero2;
        }

        public int Sum_Calculator(int numero1, int numero2)
        {
            return numero1 + numero2;
        }

        public int Calculate_Square(int numero1)
        {
            int square = numero1 * numero1;
            Console.WriteLine("{0} ^ 2 = {1}", numero1, square);
            return square;
        }

        public void Validate_Name_Calculator(string name)
        {

            Regex regex = new Regex("^[a-zA-Z]+$");
            if (!regex.IsMatch(name))
            {
                throw new Invalid_Calculator(name);
            }
            else
            {
                Console.WriteLine("The Name is correct: {0} ", name);
            }
        }

    }


    class Program

    {
        static void Main(string[] args)
        {
            Calculator calculator_1 = new Calculator();
            int[] array_numbers = { 4, 5, 6, 1, 780000000, 3, -2, -1, 0 };
            int[] array_new = new int[6];

            int number1 = 0;
            int number2 = 0;

            
            Console.WriteLine(" # 1 ");
            Console.WriteLine(" ");

            //-----------DivideByZeroException------READY--------------------------
            //Occurs when divided by zero.
            //Solution: Always validate that the denominator will be different from zero.
            try
            {
                number1 = array_numbers[0];
                number2 = array_numbers[8];
                calculator_1.Divide_Calculator(number1, number2);

            }

            catch (DivideByZeroException ex)
            {
                Console.WriteLine("This is a DivideByZeroException # 1");
                Console.WriteLine(ex.Message);
                Console.WriteLine(" ");
                Console.WriteLine(" ");
            }



            //----------IndexOutOfRangeException------READY-------------------------
            //Occurs when the iteration or certain action to be done with arrays exceeds its size.
            //Solution. Always keep an eye on the indexes of each array.
            Console.WriteLine(" # 2 ");
            Console.WriteLine(" ");
            //-----------------------------------------------------------------------
            try
            {
                for (int i = 1; i < array_numbers.Length; i++)
                {
                    Console.WriteLine(array_new[i] = 1 + array_numbers[i]);
                }
            }

            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("This is a IndexOutOfRangeException # 2");
                Console.WriteLine(ex.Message);
                Console.WriteLine(" ");
                Console.WriteLine(" ");
            }



            //----------------FormatException-----------------------------------------------------
            //Occurs when the expected type of value is not entered. In this case, a number was entered
            //and text has been entered, which is impossible to convert to a number even using int.Parse.
            Console.WriteLine(" # 3 ");
            Console.WriteLine(" ");
            //------------------------------------------------------------------------------------------
            try
            {
                Console.WriteLine("Enter instead a number enter a text by error to calculate ");
                int x = int.Parse(Console.ReadLine());
                Console.WriteLine(" ");
                calculator_1.Calculate_Square(x);

            }

            catch (Exception ex)
            {
                Console.WriteLine("This is a FormatException # 3");
                Console.WriteLine(ex.Message);
                Console.WriteLine(" ");
                Console.WriteLine(" ");
            }




            //---------------ArgumentNullException______________READY_________________________________
            //Occurs when a null value is passed by agument, usually a reference instead of a value.
            //Solution: always pass the value as an argument.
            Console.WriteLine(" # 4 ");
            Console.WriteLine(" ");
            //----------------------------------------------------------------------------------------
            try
            {
                 calculator_1.Validate_Name_Calculator(calculator_1.Operation);

                // calculator_1.Validate_Name_Objeto("multipl y");//to validate the name of operation;
            }

            catch (ArgumentNullException ex)
            {
                Console.WriteLine("This is an ArgumentNullException # 4");
                Console.WriteLine(ex.Message);
                Console.WriteLine(" ");
                Console.WriteLine(" ");
            }




            //-----------------OverflowException--------------READY--------------
            //Occurs when the value used is above the 32-bit integer support.
            //Soluction: Calculate only integer values below this size, or use data type such as double.
            Console.WriteLine(" # 5 ");
            Console.WriteLine(" ");
            //--------------------------------------------------------------------
            try
            {
                Console.WriteLine("Please Enter the number too large to calculate");
                int x = int.Parse(Console.ReadLine());
                Console.WriteLine(" ");
                calculator_1.Calculate_Square(x);
            }

            catch (OverflowException ex)
            {
                Console.WriteLine("This is a OverflowException # 5");
                Console.WriteLine(ex.Message);

            }

            //--------------------------------------------------------------------



        }


    }


}














